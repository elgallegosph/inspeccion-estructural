# Inspección Estructural

App para que ingenieros estructurales registren visitas de inspección en
campo (estructuras, hallazgos, fotos con geolocalización) y descarguen un
PDF con el informe final de cada visita. Funciona sin conexión: los datos
se guardan en el dispositivo y se sincronizan solos al recuperar señal.

## Cómo está armado

- **Frontend**: React + Vite, empaquetado como PWA (instalable, funciona
  offline gracias al service worker + caché de la app).
- **Datos**: Firebase Firestore, con persistencia local (`persistentLocalCache`)
  — por eso el formulario funciona sin internet sin lógica extra de tu parte.
- **Fotos**: Firebase Storage. Si no hay conexión al tomar la foto, se
  guarda localmente (base64) y se sube cuando el ingeniero cierra la
  visita con señal.
- **PDF**: se genera en el propio dispositivo con `jsPDF`, no depende de
  ningún servidor.
- **Hosting**: GitHub Pages, con un GitHub Action que construye y publica
  automáticamente cada vez que haces push a `main`.

## Puesta en marcha

### 1. Crear el proyecto de Firebase

1. Ve a [console.firebase.google.com](https://console.firebase.google.com) y crea un proyecto.
2. Activa **Firestore Database** (modo producción) y **Storage**.
3. Activa **Authentication > Correo/contraseña** y crea ahí las cuentas
   de los ingenieros (por ahora no hay pantalla de registro propio, se
   crean desde la consola).
4. En "Configuración del proyecto > Tus apps", crea una app web y copia
   las credenciales.

### 2. Configurar el proyecto localmente

```bash
npm install
cp .env.example .env
# pega en .env las credenciales del paso anterior
npm run dev
```

### 3. Reglas de seguridad mínimas (Firestore y Storage)

Antes de usarla con datos reales, restringe el acceso a usuarios
autenticados. En Firestore (`Rules`):

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /{document=**} {
      allow read, write: if request.auth != null;
    }
  }
}
```

Y en Storage (`Rules`) el mismo criterio (`request.auth != null`).

### 4. Desplegar a GitHub Pages

1. Sube este proyecto a un repositorio de GitHub.
2. En `vite.config.js` y `main.jsx`, si tu repositorio no se llama
   `inspeccion-estructural`, reemplaza `/inspeccion-estructural/` por
   `/<nombre-de-tu-repo>/` en ambos archivos.
3. En **Settings > Secrets and variables > Actions**, agrega las 6
   variables `VITE_FIREBASE_*` como secrets (con los mismos valores de tu `.env`).
4. En **Settings > Pages**, elige "GitHub Actions" como fuente.
5. Haz push a `main` — el workflow en `.github/workflows/deploy.yml`
   construye y publica automáticamente.

## Qué falta por definir con el equipo

Este es el esqueleto funcional, pensado para iterar. Antes de usarlo en
campo probablemente quieras ajustar:

- Los textos exactos de las listas cerradas (`src/models.js`), hoy son un
  punto de partida genérico.
- Si los ingenieros necesitan editar/eliminar hallazgos ya guardados.
- Si el PDF necesita un formato de portada más parecido al de tu plantilla
  institucional (logo, membrete, etc.) — el generador está en
  `src/utils/pdfGenerator.js` y es fácil de ajustar.
- Íconos reales de la PWA en `public/icons/` (192x192 y 512x512 px) —
  hoy están referenciados pero no incluidos.
